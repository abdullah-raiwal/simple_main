  

def test_generic():
    a =4
    b =4

    assert a==b